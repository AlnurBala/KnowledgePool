package com.example.knowpoolwebsite.exception;

public class NotDataFound extends RuntimeException {
    public NotDataFound(String msg) {
        super(msg);
    }
}
