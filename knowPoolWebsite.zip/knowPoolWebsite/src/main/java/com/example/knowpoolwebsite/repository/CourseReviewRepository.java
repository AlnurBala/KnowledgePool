package com.example.knowpoolwebsite.repository;

import com.example.knowpoolwebsite.entity.CourseReview;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseReviewRepository extends JpaRepository<CourseReview, Integer> {
}
