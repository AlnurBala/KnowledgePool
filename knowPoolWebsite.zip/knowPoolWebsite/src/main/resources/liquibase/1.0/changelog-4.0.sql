CREATE TABLE Categories (
    category_id INT PRIMARY KEY,
    name VARCHAR(255)
);