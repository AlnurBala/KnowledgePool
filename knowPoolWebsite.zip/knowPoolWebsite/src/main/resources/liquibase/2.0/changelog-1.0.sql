CREATE TABLE Users
(
    user_id         INT PRIMARY KEY,
    name            VARCHAR(255),
    email_address   VARCHAR(255),
    password        VARCHAR(255),
    payment_details VARCHAR(255),
    advertisement   VARCHAR(255)
);

