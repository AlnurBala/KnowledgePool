package com.example.knowpoolwebsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KnowPoolWebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
